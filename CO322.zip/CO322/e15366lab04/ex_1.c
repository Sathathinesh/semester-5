/*  Design and implement a Trie node structure and associated operations and algorithms to
store and retrieve a collection of English words.
E/15/366
Lab 04 .
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <ctype.h> 

#define ALPHABET_SIZE 26

int count = 0 ;
    
// trie node 
struct TrieNode 
{ 
    struct TrieNode *children[ALPHABET_SIZE]; 
  
    // isEndOfWord is true if the node represents 
    // end of a word 
    bool isEndOfWord; 
}; 
  
// Returns new trie node (initialized to NULLs) 
struct TrieNode *getNode(void) 
{ 
    struct TrieNode *pNode = NULL; 
  
    pNode = (struct TrieNode *)malloc(sizeof(struct TrieNode)); 
  
    if (pNode) 
    { 
        int i; 
  
        pNode->isEndOfWord = false; 
  
        for (i = 0; i < ALPHABET_SIZE; i++) 
            pNode->children[i] = NULL; 
    } 
    count++ ;
    return pNode; 
} 
  
// If not present, inserts key into trie 
// If the key is prefix of trie node, just marks leaf node 
int insert(struct TrieNode *head, char* str)
{
	// start from root node
	struct TrieNode* curr = head;
	while (*str)
	{
		// create a new node if path doesn't exists
		if (curr->children[*str - 'a'] == NULL)
			curr->children[*str - 'a'] = getNode();

		// go to next node
		curr = curr->children[*str - 'a'];

		// move to next character
		str++;
	}
     // mark current node as leaf
	curr->isEndOfWord = 1;
}

    
char *addend (char *slice, char part) {

	char *str = malloc (sizeof (char) * (strlen (slice) + 2));
	
	int i = 0;
	while (slice[i] != '\0') str[i] = slice[i++];

	str[i++] = part;
	str[i] = '\0';

	return str;
}

// print the word
void print(struct TrieNode *ele, char *slice) {

	if (ele == NULL) return;

 	if (ele->isEndOfWord) printf("%s\n", slice);

	for (int i = 0; i < 26; i++)
		if(ele->children[i] != NULL)
			print (ele->children[i], addend(slice, i + 97));
}

// get the file input and word 
void  printSuggestions(char *fi ,char *prefix){
	int j,i=0;
    FILE *fileP ;
    char data[50];
    fileP = fopen(fi, "r") ;
	struct TrieNode *root = getNode();
    clock_t start, time;
	 start=clock();
	while(!feof(fileP) )
		{fscanf ( fileP,"%s", data);

            for(i=0;i<strlen(data);i++){
                if(isupper(data[i])){
                    data[i]=tolower(data[i]);}
            }
            for(i=0;i<strlen(data);++i){
        while (!( (data[i] >= 'a' && data[i] <= 'z') || (data[i] >= 'A' && data[i] <= 'Z') || data[i] == '\0') )
        {for(j = i; data[j] != '\0'; ++j)
            {
                data[j] = data[j+1];
            }
            data[j] = '\0';
        }
        }
			insert(root,data);

		}
         time=clock()-start;
		 
    if (root == NULL)
		printf("Trie empty!!\n");   			// Trie is empty now
    
	
	int len = strlen (prefix);
	for (int i = 0; i < len; i++) root = root->children[prefix[i] % 97];
	
	print(root, prefix);   // print function 
	fclose(fileP); 
	int oneNodeSize=sizeof(*root); //getting the single node size

  printf("number of nodes %d\n",count); //node count
  printf("Size of a node %d\n",oneNodeSize); //size of a one node size
  printf("Memory need to store the list=%d Bytes\n",count*oneNodeSize);
  printf("\nTime taken to insert the list %f sec\n",((double)time)/CLOCKS_PER_SEC);
}

// main 
int main(int argc, char *argv[]) 
{ 
   // file name and complete word name passing through the arguments
   // argv[1]= file name ;
   // argv[2] = word ;
     clock_t start, time;
   
   if(argc == 3){ 
     printf("Auto-complete words\n");
     printf("-----------------------\n");
	 start = clock();
     printSuggestions(argv[1],argv[2]);
	 
	   time = clock()-start;
      printf("\nTime taken to print the list of words %f sec\n",((double)time)/CLOCKS_PER_SEC);
	  //used total memory
    return 0; 
   }
   else {
	   printf(" input should be ---- > ex.exe file_name auto_comp_word\n");
	   return 0 ;
   }
} 