#include <stdio.h>
#define NODE 7

int graph[NODE][NODE] = {
   {1,1,1,0,0,0,0},
   {0,1,0,0,1,0,0},
   {0,0,1,0,0,1,0},
   {0,1,0,1,1,0,1},
   {0,0,0,0,1,0,1},
   {0,0,0,1,0,1,0},
   {0,1,0,0,0,0,1},

};
int result[NODE][NODE];
int main()
{for(int i = 0; i<NODE; i++){
      for(int j = 0; j<NODE; j++){
         result[i][j] = graph[i][j];  }}  //initially copy the graph to the result matrix
   for(int k = 0; k<NODE; k++){
      for(int i = 0; i<NODE; i++){
         for(int j = 0; j<NODE; j++){
            result[i][j] = result[i][j] || (result[i][k] && result[k][j]);}}}
   for(int i = 0; i<NODE; i++) {          //print the result matrix
      for(int j = 0; j<NODE; j++){
   printf("%d",result[i][j]) ;      
      }
     printf("\n");    
   }
  return 0;
}