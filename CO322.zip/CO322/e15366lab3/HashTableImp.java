class HashTableImp implements HashTable {
 /**
    * Keys that have the same hash code are placed together in a linked list.  
    * This private nested class is used internally to implement linked lists.  
    * A ListNode holds a (key,value) pair.  
    */
   private static class ListNode {
      String key;
      int value =0;
      ListNode next;  // Pointer to next node in the list;
                      // A null marks the end of the list.
   }

   private ListNode[] table;  // The hash table, represented as
                              // an array of linked lists.

   private int count;  // The number of (key,value) pairs in the
                       // hash table.

   
   /**
    * Create a hash table
    */
   public HashTableImp(int buckets) {
      table = new ListNode[buckets];
   }

    /**
    * Retrieve the value associated with the specified key in the table, 
    * if there is any.  If not, the value null will be returned.
    * @return the associated value, or null if there is no associated value
    */
   public int search(String key) {
      
      int bucket = hash(key);  // At what location should the key be?
      
      ListNode list = table[bucket];  // For traversing the list.
      while (list != null) {
            // Check if the specified key is in the node that
            // list points to.  If so, return the associated value.
         if (list.key.equals(key))
            return list.value;
         list = list.next;  // Move on to next node in the list.
      }
      
      // If we get to this point, then we have looked at every
      // node in the list without finding the key.  Return
      
      return 0;  
   }
   
   /**
    * Return the number of key/value pairs in the table.
    */
   public int tablesize() {
      return count;
   }
   
   
   /**
    * Test whether the specified key has an associated value in the table.
    * @return true if the key exists in the table, false if not
    */
   public boolean containsKey(String key) {
      
      int bucket = hash(key);  // In what location should key be?
      
      ListNode list = table[bucket];  // For traversing the list.
      while (list != null) {
            // If we find the key in this node, return true.
         if (list.key.equals(key))
            return true;
         list = list.next;
      }
      
      // If we get to this point, we know that the key does
      // not exist in the table.
      
      return false;
   }

   /**
    * Associate the specified value with the specified key.
    * Precondition:  The key is not null.
    */
   public void insert(String key) {
      
      int bucket = hash(key); // Which location should this key be in?
      
      ListNode list = table[bucket]; // For traversing the linked list
                                     // at the appropriate location.
      while (list != null) {
            // Search the nodes in the list, to see if the key already exists.
         if (list.key.equals(key))
            break;
         list = list.next;
      }
      
      // At this point, either list is null, or list.key.equals(key).
      
      if (list != null) {
            // Since list is not null, we have found the key.
            // Just change the associated value.
         list.value++;
      }
      else {
             // Since list == null, the key is not already in the list.
             // Add a new node at the head of the list to contain the
             // new key and its associated value.
         ListNode newNode = new ListNode();
         newNode.key = key;
         newNode.value++;
         newNode.next = table[bucket];
         table[bucket] = newNode;
         count++;  // Count the newly added key.
      }
   }
 
   // hash function
	public int hash(String key){
		int in=0;    // initial value is zero
		int pr=73;   // small prime number next change into 73
		
		for(int i=0;i<key.length();i++){
			in=(in*pr+key.charAt(i))%table.length;     //sum of the ascci values of the word
		}
		
		return in;//return modulus of in .
	}  
	
	public void getBucketSize(int size){
		int m=0,max=0,min=100000;
		float dev=0;
		float average =(float) count/size;
		
		
		for(int i=0;i<size;i++){
			ListNode newNode = table[i];
			while(newNode != null){
				m++;
				newNode = newNode.next;
			}
			if(max<m){
				max=m;
				}//find maximum no of entries
			if(min>m){
				min=m;
				}//find minimum no of entries
			System.out.println("Bucket "+(i+1)+" -->  number of elements = "+m); //display no of entries in the bucket
			dev += Math.pow((m-average),2);
			m=0;
		}
		
		double deviation = Math.sqrt(dev/size);
		System.out.println(" ");
		System.out.println("-------------------------------------------------------");
		System.out.println("The minimum no of entries = "+min);
	    System.out.println("The maximum no of entries = "+max);
		System.out.println("Total elements = "+tablesize()); 
		System.out.println("Average no of elements per bucket = "+average);
		System.out.println("Standard deviation = "+deviation);
		
	}

	
}