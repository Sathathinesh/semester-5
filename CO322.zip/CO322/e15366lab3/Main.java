import java.io.*;
import java.util.*;

public class Main extends HashTableImp{
	
	public Main(int size){
		super(size);
	}
	
	public static void main(String []args){
		String str;
		
		if(args.length==2){
			int tsize = Integer.valueOf(args[0]); //get hashtable size from arguement
			Main hashMain = new Main(tsize);
			String fileName = args[1]; //get the fileName using arguement
			
			try{
				BufferedReader buffer = new BufferedReader(new FileReader(fileName));
				while((str=buffer.readLine())!=null){
					String s = str.replaceAll("\\W"," ");//replace alphanumeric characters from whitespaces
					String split[] = s.split("\\s+");//split lines
					
					for(String string:split){
						hashMain.insert(string);// insert strings into hash table
					}	
				}	
			}catch(Exception e){
				System.out.println(e);	
			}
			
			hashMain.getBucketSize(tsize);//display no of elements in each bucket
			
		}else{
			System.out.println("wrong arguements intput the size and file name");  // input the correct way 
		}
		
	}	
}