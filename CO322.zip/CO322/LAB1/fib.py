#!/usr/bin/python

import time
from datetime import timedelta
start_time = time.monotonic()

def fib_r(x) :
    if (x <= 2):
        return 1
    return fib_r(x-1) + fib_r(x-2)

#x = 0
y = input("Enter your value: ") 
x = int(y)
start_time = time.monotonic()

print ("Fib of " + str(x) + " = " + str(fib_r(x)))
end_time = time.monotonic()
print(timedelta(seconds=end_time - start_time))

# print ("Fib of " + str(x) + " = " + str(fib_i(x)))




