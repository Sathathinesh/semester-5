
import java.util.concurrent.TimeUnit;

class Fib {

    public static int fib_r(int x) {
	if(x <= 2) return 1;
	return fib_r(x-1) + fib_r(x-2);
    }

    public static void main(String [] args) throws InterruptedException{
		
	long startTime = System.nanoTime();
	int x = Integer.parseInt( args[0] );
	System.out.println("Fib of " + x + " = " + fib_r(x));
	long endTime = System.nanoTime();
    // get difference of two nanoTime values
    long timeElapsed = endTime - startTime;
 
    System.out.println("Execution time in nanoseconds  : " + timeElapsed);
 
	//System.out.println("Fib of " + x + " = " + fib_i(x));
    }
}

	
