
import java.util.concurrent.TimeUnit;

class Fib2 {

    public static int fib_i(int x) {
	int a=1, b=1, fib=1, i=2;
	while(i<x) {
	    fib = a + b;
	    a = b;
	    b = fib;
	    i+=1;
	}
	return fib;
    }

    public static void main(String [] args) throws InterruptedException{
		
    long startTime = System.nanoTime();
  //  long startTime = System.currentTimeMillis();
  //Stopwatch timer = new Stopwatch().start();
	int x = Integer.parseInt( args[0] );
	System.out.println("Fib of " + x + " = " + fib_i(x));
	long endTime = System.nanoTime();
   // long stopTime = System.currentTimeMillis();
 
    // get difference of two nanoTime values
    long timeElapsed = endTime - startTime;
 
    System.out.println("Execution time in nanoseconds  : " + timeElapsed);
 
//	System.out.println("Fib of " + x + " = " + fib_i(x));
    }
}

	
