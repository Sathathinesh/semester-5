#!/usr/bin/python

import time
from datetime import timedelta
#start_time = time.monotonic()

def fib_i(x) :
    a = 1
    b = 1
    fib = 1
    i = 2
    while i < x:
        fib = a +b
        a = b
        b = fib
        i+=1
        
    return fib

y = input("Enter your value: ") 
x = int(y)
start_time = time.monotonic()

#("Fib of " + str(x) + " = " + str(fib_i(x)))
print ("Fib of " + str(x) + " = " + str(fib_i(x)))

end_time = time.monotonic()
print(timedelta(seconds=end_time - start_time))





