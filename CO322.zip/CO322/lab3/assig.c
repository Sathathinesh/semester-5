#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHAR_SIZE 26

// A Trie node
struct Trie
{
	int isLeaf;	// 1 when node is a leaf node
	struct Trie* character[CHAR_SIZE];
};

// Function that returns a new Trie node
struct Trie* getNewTrieNode()
{int i;
	struct Trie* node = (struct Trie*)malloc(sizeof(struct Trie));
	node->isLeaf = 0;

	for ( i = 0; i < CHAR_SIZE; i++)
		node->character[i] = NULL;

	return node;
}

// Iterative function to insert a string in Trie
int insert(struct Trie *head, char* str)
{
	// start from root node
	struct Trie* curr = head;
	while (*str)
	{
		// create a new node if path doesn't exists
		if (curr->character[*str - 'a'] == NULL)
			curr->character[*str - 'a'] = getNewTrieNode();

		// go to next node
		curr = curr->character[*str - 'a'];

		// move to next character
		str++;
	}

	// mark current node as leaf
	curr->isLeaf = 1;
}

// Iterative function to search a string in Trie. It returns 1
// if the string is found in the Trie, else it returns 0
int search(struct Trie* head, char* str,int strl)
{int i=0;
int j;
char a[20];
char c[20];
for(j=0;j<20;j++){
    a[j]='\0';
}
	j=0;// return 0 if Trie is empty
	if (head == NULL)
		return 0;

	struct Trie* curr = head;
	while (*str)
	{
		// go to next node
		curr = curr->character[*str - 'a'];
    printf("string %d\n",strl);
		// if string is invalid (reached end of path in Trie)
		if (curr == NULL)
			return 0;

		// move to next character
        a[i]=*str;
        i++;
		str++;
	}
printf("string %s\n",a);
	// if current node is a leaf and we have reached the
	// end of the string, return 1
	if(curr->isLeaf==0){
            for(i=0;i<26;i++){if(curr->character[i]){

           printf("next char %s \n",a);} //}
            }
    }
	return curr->isLeaf;
}
char *append (char *slice, char part) {

	char *str = malloc (sizeof (char) * (strlen (slice) + 2));

	int i = 0;
	while (slice[i] != '\0') str[i] = slice[i++];

	str[i++] = part;
	str[i] = '\0';

	return str;
}

void print(struct Trie *ele, char *slice) {
int i;
	if (ele == NULL) return;

	if (ele->isLeaf) printf("%s\n", slice);

	for ( i = 0; i < 26; i++)
		if(ele->character[i] != NULL)
			print (ele->character[i], append (slice, i + 97));
}

void autocomplete(struct Trie *ele, char *prefix) {
int i;
	int len = strlen (prefix);
	for ( i = 0; i < len; i++) ele = ele->character[prefix[i] % 97];

	print (ele, prefix);
}
// returns 1 if given node has any children
int haveChildren(struct Trie* curr)
{int i;
	for ( i = 0; i < CHAR_SIZE; i++)
		if (curr->character[i])
			return 1;	// child found

	return 0;
}

// Recursive function to delete a string in Trie
int deletion(struct Trie **curr, char* str)
{
	// return if Trie is empty
	if (*curr == NULL)
		return 0;

	// if we have not reached the end of the string
	if (*str)
	{
		// recur for the node corresponding to next character in
		// the string and if it returns 1, delete current node
		// (if it is non-leaf)
		if (*curr != NULL && (*curr)->character[*str - 'a'] != NULL &&
			deletion(&((*curr)->character[*str - 'a']), str + 1) &&
			(*curr)->isLeaf == 0)
		{
			if (!haveChildren(*curr))
			{
				free(*curr);
				(*curr) = NULL;
				return 1;
			}
			else {
				return 0;
			}
		}
	}

	// if we have reached the end of the string
	if (*str == '\0' && (*curr)->isLeaf)
	{
		// if current node is a leaf node and don't have any children
		if (!haveChildren(*curr))
		{
			free(*curr); // delete current node
			(*curr) = NULL;
			return 1; // delete non-leaf parent nodes
		}

		// if current node is a leaf node and have children
		else
		{
			// mark current node as non-leaf node (DON'T DELETE IT)
			(*curr)->isLeaf = 0;
			return 0;	   // don't delete its parent nodes
		}
	}

	return 0;
}

// Trie Implementation in C - Insertion, Searching and Deletion
int main()
{
    int i=0;
    int j=0;
    FILE *filePointer ;
    char dataToBeRead[50];
    filePointer = fopen("wordlist70000.txt", "r") ;
	struct Trie* head = getNewTrieNode();


	while(!feof(filePointer) )
		{fscanf ( filePointer,"%s", dataToBeRead );

            for(i=0;i<strlen(dataToBeRead);i++){
                if(isupper(dataToBeRead[i])){
                    dataToBeRead[i]=tolower(dataToBeRead[i]);}
            }
            for(i=0;i<strlen(dataToBeRead);++i){
        while (!( (dataToBeRead[i] >= 'a' && dataToBeRead[i] <= 'z') || (dataToBeRead[i] >= 'A' && dataToBeRead[i] <= 'Z') || dataToBeRead[i] == '\0') )
        {for(j = i; dataToBeRead[j] != '\0'; ++j)
            {
                dataToBeRead[j] = dataToBeRead[j+1];
            }
            dataToBeRead[j] = '\0';
        }
    }
			insert(head,dataToBeRead);

		}




 printf("Enter a string: ");
    gets(dataToBeRead);
	//printf("%d\n", search(head, "ab",strlen("ability")));
    autocomplete(head,dataToBeRead);
	if (head == NULL)
		printf("Trie empty!!\n");


fclose(filePointer) ;
	return 0;
}
