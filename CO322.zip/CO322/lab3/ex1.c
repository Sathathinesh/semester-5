#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LSIZ 1000
#define RSIZ 1000 

int main(void) 
{
    char line[RSIZ][LSIZ];
//	char fname[50];
    FILE *fptr = NULL; 
    int i = 0;
    int tot = 0;
    printf("\n Read the file and store the lines into an array :\n");
	printf("------------------------------------------------------\n"); 
//	printf(" Input the filename to be opened : ");
//	scanf("%s",fname);	
 // fname = "wordlist1000.txt";
    fptr = fopen("wordlist1000.txt", "r");
    while(fgets(line[i], LSIZ, fptr)) 
	{
        line[i][strlen(line[i]) - 1] = '\0';
        i++;
    }
    tot = i;
//	printf("\n The content of the file %s  are : \n",fname);    
    for(i = 0; i < tot; ++i)
    {
        printf(" %s\n", line[i]);
    }
    printf("\n");
    return 0;
}

