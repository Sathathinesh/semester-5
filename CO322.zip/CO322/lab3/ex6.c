#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <stdbool.h>
#include <ctype.h> 


struct node // a structure to represent tree nodes 
{
    char* key;
    int len;
    node* link;
    node* next;
    node(char* x, int n) : len(n), link(0), next(0) 
    { 
        key = new char[n]; 
        strncpy(key,x,n);	
    }
    ~node() { delete[] key; }
};

int prefix(char* x, int n, char* key, int m) // length of the biggest common prefix of x and key strings 
{
    for( int k=0; k<n; k++ )
        if( k==m || x[k]!=key[k] ) 
            return k;
    return n;
}

node* find(node* t, char* x, int n=0) // x key search in t tree 
{
    if( !n ) n = strlen(x)+1; 
    if( !t ) return 0;
    int k = prefix(x,n,t->key,t->len);
    if( k==0 ) return find(t->next,x,n); // let’s look for the child’s node 
    if( k==n ) return t;
    if( k==t->len ) return find(t->link,x+k,n-k); // let’s look for at the child’s node 
    return 0; 
}

void split(node* t, int k) // dividing t node according to k key symbol 
{
    node* p = new node(t->key+k,t->len-k);
    p->link = t->link;
    t->link = p;
    char* a = new char[k];
    strncpy(a,t->key,k);
    delete[] t->key;
    t->key = a;
    t->len = k;
}

node* insert(node* t, char* x, int n=0) // inserting x key in t tree 
{
    if( !n ) n = strlen(x)+1;
    if( !t ) return new node(x,n);
    int k = prefix(x,n,t->key,t->len);
    if( k==0 ) t->next = insert(t->next,x,n);
    else if( k<n )
    {
        if( k<t->len ) // cut or not to cut?
            split(t,k);
        t->link = insert(t->link,x+k,n-k);
    }
    return t;
}


    
char *addend (char *slice, char part) {

	char *str = malloc (sizeof (char) * (strlen (slice) + 2));
	
	int i = 0;
	while (slice[i] != '\0') str[i] = slice[i++];

	str[i++] = part;
	str[i] = '\0';

	return str;
}

// print the word
void print(struct TrieNode *ele, char *slice) {

	if (ele == NULL) return;

 	if (ele->isEndOfWord) printf("%s\n", slice);

	for (int i = 0; i < 26; i++)
		if(ele->children[i] != NULL)
			print (ele->children[i], addend(slice, i + 97));
}

// get the file input and word 
void  printSuggestions(char *fi ,char *prefix){
	int j,i=0;
    FILE *fileP ;
    char data[50];
    fileP = fopen(fi, "r") ;
	struct TrieNode* root = getNode();

	while(!feof(fileP) )
		{fscanf ( fileP,"%s", data);

            for(i=0;i<strlen(data);i++){
                if(isupper(data[i])){
                    data[i]=tolower(data[i]);}
            }
            for(i=0;i<strlen(data);++i){
        while (!( (data[i] >= 'a' && data[i] <= 'z') || (data[i] >= 'A' && data[i] <= 'Z') || data[i] == '\0') )
        {for(j = i; data[j] != '\0'; ++j)
            {
                data[j] = data[j+1];
            }
            data[j] = '\0';
        }
        }
			insert(root,data);

		}

    if (root == NULL)
		printf("Trie empty!!\n");   			// Trie is empty now
    
	
	int len = strlen (prefix);
	for (int i = 0; i < len; i++) root = root->children[prefix[i] % 97];
	
	print(root, prefix);   // print function 
	fclose(fileP); 
	
}

// main 
int main(int argc, char *argv[]) 
{ 
   // file name and complete word name passing through the arguments
   // argv[1]= file name ;
   // argv[2] = word ;
   if(argc == 3){ 
     printf("Auto-complete words\n");
     printf("-----------------------\n");
     printSuggestions(argv[1],argv[2]);
    return 0; 
   }
   else {
	   printf(" input should be ---- > ex.exe file_name auto_comp_word\n");
	   return 0 ;
   }
} 
