
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <stdbool.h>
#include <ctype.h>

typedef struct TrieNode
{
  char c;
  struct TrieNode *parent;
  struct TrieNode **children;
  bool isEndOfWord;
} TrieNode;

struct TrieNode *create_trienode( struct TrieNode *parent)
{
  struct TrieNode *node = malloc(sizeof(struct TrieNode));
  //node->c = c;
  node->parent = parent;
  node->children = malloc(26*sizeof(struct TrieNode));
  node->isEndOfWord=false;
  return node;
}

void destroy_trienode(struct TrieNode *node)
{
  int i;

  if(node==NULL)
  {
      return;
  }

  for(i=0; i<26; i++)
  {
      destroy_trienode(node->children[i]);
  }

  free(node->children);
  free(node);
  return;
}

    
char *addend (char *slice, char part) {

	char *str = malloc (sizeof (char) * (strlen (slice) + 2));
	
	int i = 0;
	while (slice[i] != '\0') str[i] = slice[i++];

	str[i++] = part;
	str[i] = '\0';

	return str;
}

// print the word
void print(struct TrieNode *ele, char *slice) {

	if (ele == NULL) return;

 	if (ele->isEndOfWord) printf("%s\n", slice);

	for (int i = 0; i < 26; i++)
		if(ele->children[i] != NULL)
			print (ele->children[i], addend(slice, i + 97));
}

// get the file input and word 
void  printSuggestions(char *fi ,char *prefix){
	int j,i=0;
    FILE *fileP ;
    char data[50];
    fileP = fopen(fi, "r") ;
	struct TrieNode* root = getNode();

	while(!feof(fileP) )
		{fscanf ( fileP,"%s", data);

            for(i=0;i<strlen(data);i++){
                if(isupper(data[i])){
                    data[i]=tolower(data[i]);}
            }
            for(i=0;i<strlen(data);++i){
        while (!( (data[i] >= 'a' && data[i] <= 'z') || (data[i] >= 'A' && data[i] <= 'Z') || data[i] == '\0') )
        {for(j = i; data[j] != '\0'; ++j)
            {
                data[j] = data[j+1];
            }
            data[j] = '\0';
        }
        }
			insert(root,data);

		}

    if (root == NULL)
		printf("Trie empty!!\n");   			// Trie is empty now
    
	
	int len = strlen (prefix);
	for (int i = 0; i < len; i++) root = root->children[prefix[i] % 97];
	
	print(root, prefix);   // print function 
	fclose(fileP); 
	
}

// main 
int main(int argc, char *argv[]) 
{ 
   // file name and complete word name passing through the arguments
   // argv[1]= file name ;
   // argv[2] = word ;
   if(argc == 3){ 
     printf("Auto-complete words\n");
     printf("-----------------------\n");
     printSuggestions(argv[1],argv[2]);
    return 0; 
   }
   else {
	   printf(" input should be ---- > ex.exe file_name auto_comp_word\n");
	   return 0 ;
   }
} 
