// C implementation of search and insert operations 
// on Trie 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <stdbool.h>
#include <ctype.h> 
 
#define ALPHABET_SIZE 26
  
// trie node 
 struct TrieNode{ 
    struct TrieNode *children[ALPHABET_SIZE]; 
  
    // isEndOfWord is true if the node represents 
    // end of a word 
    bool isEndOfWord; 
}; 
  
// Returns new trie node (initialized to NULLs) 
struct TrieNode *createNode(void) 
{ 
    struct TrieNode *pNode = NULL; 
  
    pNode = (struct TrieNode *)malloc(sizeof(struct TrieNode)); 
  
    if (pNode) 
    { 
        int i; 
  
        pNode->isEndOfWord = false; 
  
        for (i = 0; i < ALPHABET_SIZE; i++) 
            pNode->children[i] = NULL; 
    } 
  
    return pNode; 
} 
  
// If not present, inserts key into trie 
// If the key is prefix of trie node, just marks leaf node 
int insert(struct TrieNode *head, char* str)
{
	// start from root node
	struct TrieNode* curr = head;
	while (*str)
	{
		// create a new node if path doesn't exists
		if (curr->children[*str - 'a'] == NULL)
			curr->children[*str - 'a'] = createNode();

		// go to next node
		curr = curr->children[*str - 'a'];

		// move to next character
		str++;
	}

	// mark current node as leaf
	curr->isEndOfWord = 1;
}



// If all children are NULL, return 1. 
bool isLastNode(struct TrieNode* root) 
{ 
    for (int i = 0; i < ALPHABET_SIZE; i++) 
        if (root->children[i]) 
            return 0; 
    return 1; 
} 
    
char *append (char *slice, char part) {

	char *str = malloc (sizeof (char) * (strlen (slice) + 2));
	
	int i = 0;
	while (slice[i] != '\0') str[i] = slice[i++];

	str[i++] = part;
	str[i] = '\0';

	return str;
}

void print(struct TrieNode *ele, char *slice) {

    int len = strlen (slice);
	for (int i = 0; i < len; i++) ele = ele->children[slice[i] % 97];
	

	if (ele == NULL) return;

 	if (ele->isEndOfWord) printf("%s\n", slice);

	for (int i = 0; i < 26; i++)
		if(ele->children[i] != NULL)
			print (ele->children[i], append(slice, i + 97));
}
/*
void autocomplete(struct TrieNode *ele, char *prefix) {

	int len = strlen (prefix);
	for (int i = 0; i < len; i++) ele = ele->children[prefix[i] % 97];
	
	print (ele, prefix);
}*/

 
// Driver 
int main() 
{ 
   int i=0;
    FILE *filePointer ;
    char dataToBeRead[50];
    filePointer = fopen("wordlist1000.txt", "r") ;
	struct TrieNode* head = createNode();


	while(!feof(filePointer) )
		{fscanf ( filePointer,"%s", dataToBeRead );
           /* for(i=0;i<20;i++){
                a[i] = dataToBeRead[i];
            }*/
            for(i=0;i<strlen(dataToBeRead);i++){
                if(isupper(dataToBeRead[i]))
                    dataToBeRead[i]=tolower(dataToBeRead[i]);
            }
			insert(head,dataToBeRead);
			//printf( " %s \n" ,dataToBeRead) ;
		}

		// Closing the file using fclose()



	//printf("%d\n", search(head, "ab",strlen("ability")));   	// print 0 + newline
    print(head,"att");
	if (head == NULL)
		printf("Trie empty!!\n");   			// Trie is empty now

    return 0; 
} 