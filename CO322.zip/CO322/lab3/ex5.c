// C implementation of search and insert operations 
// on Trie 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <stdbool.h>
#include <ctype.h> 


#define LSIZ 1000
 #define RSIZ 1000 
  
// #define ARRAY_SIZE(a) sizeof(a)/sizeof(a[0]) 
  
// Alphabet size (# of symbols) 
#define ALPHABET_SIZE 26
  
// Converts key current character into index 
// use only 'a' through 'z' and lower case 
//#define CHAR_TO_INDEX(c) ((int)c - (int)'a') 
  
// trie node 
struct TrieNode 
{ 
    struct TrieNode *children[ALPHABET_SIZE]; 
  
    // isEndOfWord is true if the node represents 
    // end of a word 
    bool isEndOfWord; 
}; 
  
// Returns new trie node (initialized to NULLs) 
struct TrieNode *getNode(void) 
{ 
    struct TrieNode *pNode = NULL; 
  
    pNode = (struct TrieNode *)malloc(sizeof(struct TrieNode)); 
  
    if (pNode) 
    { 
        int i; 
  
        pNode->isEndOfWord = false; 
  
        for (i = 0; i < ALPHABET_SIZE; i++) 
            pNode->children[i] = NULL; 
    } 
  
    return pNode; 
} 
  
// If not present, inserts key into trie 
// If the key is prefix of trie node, just marks leaf node 
int insert(struct TrieNode *head, char* str)
{
	// start from root node
	struct TrieNode* curr = head;
	while (*str)
	{
		// create a new node if path doesn't exists
		if (curr->children[*str - 'a'] == NULL)
			curr->children[*str - 'a'] = getNode();

		// go to next node
		curr = curr->children[*str - 'a'];

		// move to next character
		str++;
	}

	// mark current node as leaf
	curr->isEndOfWord = 1;
}

    
char *addEnd (char *slice, char part) {

	char *str = malloc (sizeof (char) * (strlen (slice) + 2));
	
	int i = 0;
	while (slice[i] != '\0') str[i] = slice[i++];

	str[i++] = part;
	str[i] = '\0';

	return str;
}

void  printSuggestions(struct TrieNode *ele, char *slice) {

	if (ele == NULL) return;

 	if (ele->isEndOfWord) printf("%s\n", slice);

	for (int i = 0; i < 26; i++)
		if(ele->children[i] != NULL)
			 printSuggestions (ele->children[i], addEnd(slice, i + 97));
}
void autocomplete(struct TrieNode *ele, char *prefix) {
int i;
	int len = strlen (prefix);
	for ( i = 0; i < len; i++) ele = ele->children[prefix[i] % 97];

	printSuggestions (ele, prefix);
}
/*
void printSug(char *fi,char *prefix){
	int i=0;
    FILE *filePointer ;
    char dataToBeRead[50];
    filePointer = fopen(fi, "r") ;
	struct TrieNode* head = getNode();


	while(!feof(filePointer) )
		{fscanf ( filePointer,"%s", dataToBeRead );

            for(i=0;i<strlen(dataToBeRead);i++){
                if(isupper(dataToBeRead[i]))
                    dataToBeRead[i]=tolower(dataToBeRead[i]);
            }
			insert(head,dataToBeRead);
			
		}
/*
   // char *prefix = "att" ;
    int len = strlen (prefix);
	for (i = 0; i < len; i++) head = head->children[prefix[i] % 97];
	*/
//	 printSuggestions (head, prefix);
/*
 autocomplete (head, prefix);
	if (head == NULL)
		printf("Trie empty!!\n");   			// Trie is empty now

	
}
*/
 
// Driver 
int main( int argc, char *argv[] )  {

   if( argc == 3 ) {
      printf("The argument supplied is %s\n", argv[2]);
//	 printSug(argv[1],argv[2]);
    char *prefix = argv[2];
	char *prefix2 = argv[1];
	 int i=0;
    FILE *filePointer ;
    char dataToBeRead[50];
    filePointer = fopen("wordlist1000", "r") ;
	struct TrieNode* head = getNode();
	
	while(!feof(filePointer) )
		{fscanf ( filePointer,"%s", dataToBeRead );

            for(i=0;i<strlen(dataToBeRead);i++){
                if(isupper(dataToBeRead[i]))
                    dataToBeRead[i]=tolower(dataToBeRead[i]);
            }
			insert(head,dataToBeRead);
			
		}
 
    autocomplete (head, "att");
	if (head == NULL)
		printf("Trie empty!!\n");   			// Trie is empty now

	 return 0;
    }
   else {
     // printf("Too many arguments supplied.\n");
	   printf("Enter the correct way --->.\n");
	  return 0 ;
    }
   
}