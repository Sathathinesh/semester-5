# sudo chmod uog+rwx /dev/ttyUSB0

avr-gcc -Os -DF_CPU=16000000UL -mmcu=atmega328p -o $1 $1.c 
avr-objcopy -O ihex -R .eeprom $1 binary.hex
avrdude -v -p atmega328p -c arduino -P $2 -b 115200 -D -U flash:w:binary.hex:i 