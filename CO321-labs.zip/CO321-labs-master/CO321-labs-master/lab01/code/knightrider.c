#include <avr/io.h>
#include <util/delay.h>
#define BLINK_DELAY_MS 1000

int main (void){
   DDRB = DDRB| 0b00111110 ;
   PORTB = PORTB | 0b0000010;

   while(1){

      for (int i=0;i<3;i++){
         PORTB = PORTB >> 1;
         _delay_ms(BLINK_DELAY_MS);

      }
      for (int i=0;i<3;i++){
         PORTB = PORTB << 1;
         _delay_ms(BLINK_DELAY_MS);
      }
   }
}
