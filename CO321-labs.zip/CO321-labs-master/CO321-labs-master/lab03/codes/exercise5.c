#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define BLINK_DELAY_MS 200

int main (void){

   // Timer 1
   TCNT1 = 3036;
   //TCNT1L = 0xff;
   //TCNT1H = 0x00;

   TCCR1A = 0x00; // Normal Mode
   TCCR1B = 0x04; // Timer on, pre:256

   TIMSK1 |= (1 << TOIE1);    // enable timer overflow interrupt
   sei();      					 // Enable global interrupt

   // Knight Rider
   DDRB = DDRB | 0b00111110 ;

   while(1){
      for (int i=1;i<5;i++){
         PORTB = PORTB | (1<<i);
         _delay_ms(BLINK_DELAY_MS);
         PORTB = PORTB & ~(1<<i);

      }
      for (int i=3;i>1;i--){
         PORTB = PORTB | (1<<i);
         _delay_ms(BLINK_DELAY_MS);
         PORTB = PORTB & ~(1<<i);
      }
   }
}

ISR(TIMER1_OVF_vect){
   PORTB = PORTB ^ (1<<5);

   /*TCNT1L = 0xff; TCNT1H = 0x00;*/
   TCNT1 = 3036;

}
