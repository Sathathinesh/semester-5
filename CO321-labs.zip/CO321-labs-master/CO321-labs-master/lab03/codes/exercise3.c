#include <avr/io.h>

void myTimer(){
	uint8_t count=0;
	TCCR0A = 0x00;
	TCCR0B = 0x04; // Timer on, 1:256 prescale
	
	while(count < 125){
		TCNT0 = 0x06;  // initial value = 6 (250 counts)

		while((TIFR0 & 0x01)==0);
		++count;

		TIFR0 = 0x01;  // Clear timer overflow
	}
}

int main (void){

	DDRB |= (1<<5);

	while(1){
		PORTB = PORTB ^ (1<<5);
		myTimer();
	}
}
