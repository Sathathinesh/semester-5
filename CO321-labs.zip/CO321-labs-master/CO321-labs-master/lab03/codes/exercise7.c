#include <avr/io.h>
#include <avr/interrupt.h>

//PB4
uint8_t count0=0;
uint8_t count1=0;

int main (void){

   DDRB |= (1<<5);
   DDRB |= (1<<1);
   // Timer 1
   TCNT0 = 131;
   TCNT1 = (65536-12500); // 12,500 x 10
   //TCNT1 = (65536-25000); // 25,000 x 5

   TCCR0A = 0x00; // Normal Mode
   TCCR0B = 0x04; // Timer on, pre:256

   TCCR1A = 0x00;
   TCCR1B = 0x03; // Timer on, pre: 64

   TIMSK0 |= (1 << TOIE0);
   TIMSK1 |= (1 << TOIE1);    // enable timer overflow interrupts
   sei();

   while(1){

   }
}

ISR(TIMER0_OVF_vect){
   ++count0;
   if(count0>25){
      PORTB ^= (1<<5);
      count0=0;
   }
   TCNT0 = 131;
}

ISR(TIMER1_OVF_vect){
   ++count1;
   if(count1>100){  // 10 , 5
      PORTB ^= (1<<1);
      count1=0;
   }
   TCNT1 = 64286;
}
