#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#define BLINK_DELAY_MS 200

uint8_t count=0;

int main (void){
   
   DDRB |= (1<<5);

   // Timer 1
   TCNT0 = 0x06;

   TCCR0A = 0x00; // Normal Mode
   TCCR0B = 0x04; // Timer on, pre:256

   TIMSK0 |= (1 << TOIE0);    // enable timer overflow interrupt
   sei();  

   while(1){
     
   }
}

ISR(TIMER0_OVF_vect){
   ++count;
   if(count>25){
     PORTB ^= (1<<5);
     count=0;
   }
   TCNT0 = 0x06;
}
