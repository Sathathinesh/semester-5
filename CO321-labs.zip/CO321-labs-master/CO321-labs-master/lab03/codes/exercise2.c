#include <avr/io.h>
//#include <util/delay.h>
//#define BLINK_DELAY_MS 1000

void myTimer(){

      TCNT0 = 131;  // initial value = 0
      TCCR0A = 0x00;
      TCCR0B = 0b00000100; // Timer on, 256

      while(TIFR0 & (0x01)==0);

      TCCR0A = 0x00;
      TCCR0B = 0x00; // Timer off

      TIFR0 = 0x01;  // Clear timer overflow
}

int main (void){
   DDRB |= (1<<5);

   while(1){
      PORTB = PORTB ^ (1<<5);
      myTimer();
   }
}
