#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#define BLINK_DELAY_MS 100

// --------------------------------------
// Counter with interrupts
// --------------------------------------

int count = 0;

int main (void){
   DDRB = DDRB | 0b00111111;   	// D8-D13   : Outputs
   DDRD = DDRD & ~(1<<2);      	// D2       : Input
   PORTB = count;                // Off all LEDs

   // Falling edge : xxxxxx10
   EICRA |= (1<<1);
   EICRA &= ~(1<<0);

   sei();      					 // Enable global interrupt
   EIMSK |= (1);  		       // enable external interrupt

   while(1){
      // Nothing to do in here
   }

   return 0;
}

ISR(INT0_vect){
   PORTB = ~PORTB;
   _delay_ms(BLINK_DELAY_MS);
}
