#include <avr/io.h>
//#include <avr/interrupt.h>
#include <util/delay.h>
#define BLINK_DELAY_MS 1000

// --------------------------------------
// Counter without using interrupts
// --------------------------------------

int main (void){
   unsigned char count = 0
   DDRB = DDRB| 0b00111111;   // D8-D13   : Outputs
   DDRD = DDRD & ~(1<<2);      // D2       : Input
   PORTB = count;             // Off all LEDs

   while(1){
      if(PIND & (1<<2))) {
         count++;                   // Count
         PORTB = count;
         _delay_ms(BLINK_DELAY_MS); // Avoid debouncing
      }
      //if(count>64)count = 0;         // Counter Overflow
      //PORTB = count;
   }
}
