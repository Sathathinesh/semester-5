#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#define BLINK_DELAY_MS 1000

// --------------------------------------
// Counter with interrupts
// --------------------------------------

char count = 0;

int main (void){

   DDRB = DDRB | 0b00111111;   	// D8-D13   : Outputs
   DDRD = DDRD & ~(3<<1);      	// D2,D3       : Inputs
   PORTB = count;             		  // Off all LEDs

   // Falling edge : xxxx1010
   EICRA = 0b00001010;

   sei();      					 // Enable global interrupt
   EIMSK |= (1<<0);  		       // enable external interrupt
   EIMSK |= (1<<1);  		       // enable external interrupt


   while(1){
      // Nothing to do in here
   }

   return 0;
}

ISR(INT0_vect){
   count++;
   PORTB = count;
   _delay_ms(BLINK_DELAY_MS);
}
ISR(INT1_vect){
   count--;
   PORTB = count;
   _delay_ms(BLINK_DELAY_MS);
}
