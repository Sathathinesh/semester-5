#include <avr/io.h>
#include <util/delay.h>
#define BLINK_DELAY_MS 1000

int main (void){
   DDRC = DDRC & ~(1<<1);  // A1 as input
   DDRD = 0xff;            // PD as output

   ADCSRA |= (1<< ADEN);   // Turn on the ADC Unit

   ADCSRA |= (1<<ADPS2) | (1<<ADPS0) | (1<<ADPS0);
   // Prescale=128, ADPS=111

   ADMUX &= ~(1<<REFS0);   // VRef , for the reference voltage
   ADMUX &= ~(1<<REFS1);   // REFS=00

   ADMUX |= (1<<ADLAR);     // ADC left adjust result

   ADMUX |= (1<<MUX0);     // Select A0 from the MUX, MUX=0001

   while(1){

      ADCSRA |= (1<<ADSC); // Start Conversion

      while(((ADCSRA>>ADIF) & 1)==0){}   // Wait until ADC conversion ends

      if(ADCH>100){
         PORTD= 0xff;
      }else{
         PORTD = 0x00;
      }

      _delay_ms(100);       // ~10 readings per second
   }
}
