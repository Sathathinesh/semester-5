#include <avr/io.h>
#include <util/delay.h>
#define BLINK_DELAY_MS 1000

int main (void){
   DDRC = DDRC & ~(1<<1);  // A1 as input
   DDRD = 0xff;            // PD as output

   ADCSRA |= (1<< ADEN);   // Turn on the ADC Unit

   ADCSRA |= (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0);
                           // Prescale=128, ADPS=111

   ADMUX |= (1<<REFS0);    // AVcc, for the reference voltage
   ADMUX &= ~(1<<REFS1);   // REFS=01

   ADMUX |= (1<<ADLAR);     // ADC left adjust result

   ADMUX |= (1<<MUX0);     // Select A1 from the MUX, MUX=001

   while(1){

      ADCSRA |= (1<<ADSC);    	// Start Conversion

      while(((ADCSRA>>ADIF) & 1)==0){}   // Wait until ADC conversion ends

      PORTD = ADCH;	// Copy value into PortD

      _delay_ms(100);       	// ~10 readings per second
   }
}
