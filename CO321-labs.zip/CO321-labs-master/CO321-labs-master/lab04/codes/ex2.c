#include <avr/io.h>
#include <util/delay.h>
#define BLINK_DELAY_MS 100

int main (void){

   DDRD |= (1<<6);

   TCNT0 = 0;
   OCR0A = 0;                 // Initial Values

   // Configure PWM signal
   TCCR0A = 0b10000011;
	TCCR0B = 0b00000011;

   // Description:
   //TCCR0A |= (1<<COM0A1);  // Enable non-inverting mode
   //TCCR0A &= ~(1<<COM0A0);

   //TCCR0A |= (1<<WGM01);   // Enable FastPWM
   //TCCR0A |= (1<<WGM00);

   //TCCR0B |= (1<<CS01);   // Pre-scale:64
   //TCCR0B |= (1<<CS00);

   while(1){
      // Slowly Fade in and out

      for(int i=0;i<255;i=i+5){
         _delay_ms(BLINK_DELAY_MS);
         ++OCR0A;
      }

      _delay_ms(500);

      for(int i=255;i>0;i=i-5){
         _delay_ms(BLINK_DELAY_MS);
         --OCR0A;
      }
      _delay_ms(500);
   }
}
