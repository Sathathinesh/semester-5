
// Old Code

#include <avr/io.h>
#include <util/delay.h>
#define BLINK_DELAY_MS 1000

int main (void){

   DDRD |= (1<<6);         // D6 ->  output

   TCNT0 = 0;              // reset Timer0 value

   TCCR0A = 0b01000010;
   TCCR0B = 0b00000100;

   // freq = fCLK / (2*N*(1+OCR0A)); N = prescale

   // 122   256 Hz (N=256)
   // 30    1024 Hz (N=256)
   // 31    4096 Hz (N=64)
   // 12    10 kHz (N=64)

   while(1){

      // 256 Hz, Prescaler : 1/256
      OCR0A = 122;
      TCCR0B = 0b00000100;
      for(int i=0;i<5;i=i+5){_delay_ms(500);}

      // 1024 Hz, Prescaler : 1/256
      OCR0A = 30;
      TCCR0B = 0b00000100;
      for(int i=0;i<5;i=i+5){_delay_ms(500);}

      // 4096 Hz, Prescaler : 1/64
      OCR0A = 31;
      TCCR0B = 0b00000011;
      for(int i=0;i<5;i=i+5){_delay_ms(500);}

      // 10 kHz, Prescaler : 1/64
      OCR0A = 12;
      TCCR0B = 0b00000011;
      for(int i=0;i<5;i=i+5){_delay_ms(500);}

   }
}
