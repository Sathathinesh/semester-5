#include <avr/io.h>
#include <util/delay.h>
#define BLINK_DELAY_MS 100

int main (void){

   DDRD |= (1<<6);
   TCNT0 = 0;

   OCR0A = 127;   // 50% PWM
   TCNT0 = 0;

   // Configure PWM signal
   TCCR0A = 0b10000011; // FastPWM, non-inverting mode
   TCCR0B = 0b00000011; // Pre-scale: 64

   while(1){
   	// Nothing
   }

}
