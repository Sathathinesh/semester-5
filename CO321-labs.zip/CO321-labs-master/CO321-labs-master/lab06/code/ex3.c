#include <avr/io.h>
#include <util/delay.h>

#define BLINK_DELAY_MS 1000
#define MYUBRR 103

void usart_init() {
   // 8bit frame, no parity, 1 stop 8bit

   UCSR0B |= (1 << TXEN0);        //1->enable transmitter
   UCSR0B |= (1 << RXEN0);        //1->enable receiver

   //00-> asynchronous usart, 01-> synchronous usart, 10-> reserved, 11-> master spi
   UCSR0C &= ~(1 << UMSEL01); // 00
   UCSR0C &= ~(1 << UMSEL00);

   //parity check 00-> disabled, 01-> reserved, 10-> enabled, even parity, 11-> enabled, odd parity
   UCSR0C &= ~(1 << UPM01); // 00
   UCSR0C &= ~(1 << UPM00);

   //stop bit select. 0->1 bit, 1->2bit
   UCSR0C &= ~(1 << USBS0); // 0

   //char size.000-> 5-bit, 001-> 6-bit, 010-> 7-bit, 011-> 8-bit, 111-> 9-bit
   UCSR0C &= ~(1 << UCSZ02); // 011
   UCSR0C |= (1 << UCSZ01);
   UCSR0C |= (1 << UCSZ00);

   // baud rate register
   UBRR0H = (unsigned char)(MYUBRR >> 8);
   UBRR0L = (unsigned char)MYUBRR;

}
unsigned char usart_receive() {
   while (((UCSR0A >> RXC0) & 1) == 0) {
   }
   return (char)UDR0;
}

void usart_send(char data) {
   UDR0 = data;
   while (((UCSR0A >> UDRE0) & 1) == 0) {
   }
}


unsigned char caesarCipher(unsigned char in) {
   if (in >= 'a' && in <= 'z') {
      return  'a' + (((in - 'a') + 3) % 26);

   } else if (in >= 'A' && in <= 'Z') {
      return  'A' + (((in - 'A') + 3) % 26);
   }
   return in;
}


int main(void) {

   unsigned char inBuffer[255];

   int i = 0;
   unsigned char temp;

   usart_init();

   while (1) {
      temp = usart_receive();
      inBuffer[i++] = temp;

      if (temp == '\n' ||  temp == '\r') {
         // Print new line
         //usart_send((unsigned char)'\n');

         for (int j = 0; j < (i - 1); j++) {
            // Apply Caesar Cipher
            usart_send((unsigned char)caesarCipher((inBuffer[j])));
         }

         // Reset values
         i = 0;
         usart_send((unsigned char)'\n');

      } else {
         //usart_send(temp);
      }
   }
   return 0;
}
