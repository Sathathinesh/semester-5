#include <avr\io.h>    // io.h contains the defnition of all ports and SFRs //
//#include <uart.h>	 //User defined UART library which contains the UART routines
//#include <eeprom.h>  //User defined library which contains eeprom routines
 
void EEPROMwrite(unsigned int address, char data);
char EEPROMread(unsigned int address);
/* start of the main program */
void main() 
{
  unsigned int eeprom_address=0x00;
  unsigned char write_string[] = {"Hello World"};
 
  /* Initialize the Uart before Transmitting/Receiving any data */
 //   UART_Init();
 int i =0;
 
   while(i<20)
    {
         //UART_TxString("\n\rWrite : ");                       //Print the message on UART
         //UART_TxString(write_string);                      //Print the String to be written 
         EEPROMwrite(eeprom_address,write_string[i]);  // Write the String at memory Location 0x00
 
         //UART_TxString("\tRead : ");                         //Print the message on UART
         EEPROMread(eeprom_address);   // Read the String from memory Location 0x00	
         //UART_TxString(read_string);                      //Print the read String
     }		
  }
  
  void EEPROMwrite(unsigned int address, char data) {
	while(EECR & (1<<EEPE));		// Wait for completion of previous write (Wait until a previous EEPROM write is finished (till EEPE becomes zero))
	
	EEAR = address;					// Setup address
	EEDR = data;					// Setup data
	
	EECR |= (1<<EEMPE);				// Write logical 1 to EEMPE
	
	EECR |= (1<<EEPE);				// Start eeprom write
}

char EEPROMread(unsigned int address) {
	while(EECR & (1<<EEPE));		// Wait for completion of write (Wait until a previous EEPROM write is finished (till EEPE becomes zero))
	
	EEAR = address;					// Setup address
		
	EECR |= (1<<EERE);				// Start eeprom read
	
	return EEDR;					// Return data
}