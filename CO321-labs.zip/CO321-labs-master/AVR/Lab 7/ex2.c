#include <avr/io.h>
#include <util/delay.h>

#define FOSC 16000000
#define BAUD 9600

void usart_init(){

	UCSR0B |= (1<<TXEN0);		//Transmitter enable
	UCSR0B |= (1<<RXEN0);		//Reciever enable
	
	UCSR0C &= ~(1<<UMSEL01 | 1<<UMSEL00);   //asynchronous
	UCSR0C &= ~(1<<UPM01 | 1<<UPM00);       //No parity
	UCSR0C &= ~(1<<USBS0);                  //1 stop bit

	UCSR0C |= (1<<UCSZ01);          //8 bit
	UCSR0C |= (1<<UCSZ00);
	UCSR0B &= ~(1<<UCSZ02);

	unsigned int X = FOSC/16/BAUD - 1 ;
	UBRR0L = X;			//Baud rate
	UBRR0H = X>>8;
}

void usart_send(char c){
	UDR0=c;
	while( !(UCSR0A & (1<<UDRE0)) ){}; //wait
}

char usart_receive(){
	char c;
	while( !(UCSR0A & (1<<RXC0) )){};  //wait
	c=UDR0;
	return c;
}

void EEPROMwrite(unsigned int address, char data){

	// wait for completion of previous write
	while (EECR & (1<<EEPE));

	// set up address and data regs
	EEAR = address;
	EEDR = data;

	// write logical 1 to EEMPE
	EECR |= (1<<EEMPE);

	// start eeprom write
	EECR |= (1<<EEPE);
}

char EEPROMread(unsigned int address){

	// wait for completion of previous write
	while (EECR & (1<<EEPE));

	// set up address
	EEAR = address;

	// start eeprom read
	EECR |= (1<<EERE);

	return EEDR;
}

int main(){
	usart_init();
	int i=0;
	int k=0;

	while(1){
		
		char c[1024];

		c[i] = usart_receive();
		while( c[i] != '\r' ){
			i++;
			c[i] = usart_receive();
		}
		
		while(k<i){
			EEPROMwrite(k,c[k]);
			k++;
		}

		int j=0;
		usart_send('\n');
		while(j<i){
			char ch = EEPROMread(j);
			usart_send(ch);
			j++;
		}

	}
	
}