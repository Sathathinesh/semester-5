#include <avr/io.h>

void EEPROMwrite(unsigned int address, char data);
char EEPROMread(unsigned int address);

int main( void )
{
	unsigned char str[43] = "E15330-Sathu E15366-Thinesh E15373-Vaheesan";
	unsigned char strLenght = 43;
	unsigned char i = 0;
	
	//USART_Init ( MYUBRR );
	//USART_Transmit('S' );	
//	EEPROMwrite(i,str[i]);
	int a;
	//unsigned char b;
	while(i<43)
	{
		//a=str[i++];
			EEPROMwrite(i,str[i]);
		
		
	}
	while(i<43)
	{
		//a=str[i++];
		
		EEPROMread( i );
		if(i >= strLenght){
			EEPROMread('\n');
		i = 0;
		}
		
	}
	return(0); 
}

void EEPROMwrite(unsigned int address, char data) {
	while(EECR & (1<<EEPE));		// Wait for completion of previous write (Wait until a previous EEPROM write is finished (till EEPE becomes zero))
	
	EEAR = address;					// Setup address
	EEDR = data;					// Setup data
	
	EECR |= (1<<EEMPE);				// Write logical 1 to EEMPE
	
	EECR |= (1<<EEPE);				// Start eeprom write
}

char EEPROMread(unsigned int address) {
	while(EECR & (1<<EEPE));		// Wait for completion of write (Wait until a previous EEPROM write is finished (till EEPE becomes zero))
	
	EEAR = address;					// Setup address
		
	EECR |= (1<<EERE);				// Start eeprom read
	
	return EEDR;					// Return data
}