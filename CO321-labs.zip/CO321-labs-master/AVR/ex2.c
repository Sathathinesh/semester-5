/*
* PD7 pin is connected to a push button. Write a program that uses 6 LEDs connected to PORTB (6 LSBs) 
* to display the number of times the push button is pressed, as a binary number.
* Implement without using external interrupts. (i.e. Use polling)
*/

#include<avr/io.h>
#include <util/delay.h>

int main()
{
	DDRD&= ~(1<<7); 			//configure pin 7 of PORTD for input (PD7 pin -> digital pin 7), switch
	DDRB|=(0b111111<<0);		//configure pin 0,1,2,3,4,5 of PORTB for output (PB5 pin -> digital pin 13), 6-leds
	int count = 0;

	while(1)
	{
		if((PIND&(1<<7)))		//if input to Port D pin 7 is high ie.if(PD7==1)
		{
			count++;
			
			if(count > 63)
			{
				count =1;
			}

			PORTB = (0b111111 & count);
			_delay_ms(400);
			//PORTB =0x00;
		}
		//else
			//PORTB&= ~(0b111111<<0);//led on, PB0=0
	}
}