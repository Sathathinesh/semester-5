#include <avr/io.h> 
#include <util/delay.h> 
 
#define BLINK_DELAY_MS  100
 
int main (void){ 
 
 DDRB = 0xFF;        /* configure pin 5 of PORTB for output*/ 
 int i ;
 while(1){ 
    

 for(i=5;i>=2;i--){
    PORTB = PORTB | (1<<i);    /* set pin 5 high to turn led on */    
	_delay_ms(BLINK_DELAY_MS); 
 
    PORTB = PORTB &~(1<<i);   /* set pin 5 low to turn led off */ 
 
    _delay_ms(BLINK_DELAY_MS); 
 }
 for(i=2;i<5;i++){
    PORTB = PORTB | (1<<i);    /* set pin 5 high to turn led on */    
	_delay_ms(BLINK_DELAY_MS); 
 
    PORTB = PORTB &~(1<<i);   /* set pin 5 low to turn led off */ 
 
    _delay_ms(BLINK_DELAY_MS); 
     }
 }
} 