#include<avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
int count = 0;

int main()
{
//	DDRD&= ~(1<<7); 			//configure pin 7 of PORTD for input (PD7 pin -> digital pin 7), switch
	DDRB|=(0b111111<<0);		//configure pin 0,1,2,3,4,5 of PORTB for output (PB5 pin -> digital pin 13), 6-leds
	DDRD &= ~(1<<2);		
	//DDRB = 0b00000001 ; 
	EICRA |= (1<<ISC01); 	//set for falling edge detection
	EICRA &= ~(1<<ISC00); 	//set for falling edge detection

	sei(); 					//enable global interrupts
	
	EIMSK |= (1<<INT0); 	//enable external interrupt for int0
	
	while(1){
		
	}
return 0;
}
ISR(INT0_vect){				//When an interrupt is invoked, the microcontroller runs the interrupt service routine.
	//PORTB = ~PORTB;
				count++;
			
			if(count > 63)
			{
				count =1;
			}

			PORTB = (0b111111 & count);
			_delay_ms(400);
}