/*
* PD7 pin is connected to a push button. Write a program that uses 6 LEDs connected to PORTB (6 LSBs) 
* to display the number of times the push button is pressed, as a binary number.
* Implement without using external interrupts. (i.e. Use polling)
*/

#include<avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

int main()
{
//	DDRD&= ~(1<<7); 			//configure pin 7 of PORTD for input (PD7 pin -> digital pin 7), switch
	DDRB|=(0b111111<<0);		//configure pin 0,1,2,3,4,5 of PORTB for output (PB5 pin -> digital pin 13), 6-leds
	DDRD &= ~(1<<2);		
	//DDRB = 0b00000001 ; 
	EICRA |= (1<<ISC01); 	//set for falling edge detection
	EICRA &= ~(1<<ISC00); 	//set for falling edge detection
	
	sei(); 					//enable global interrupts
	
	EIMSK |= (1<<INT0); 	//enable external interrupt for int0
	
	while(1){
		
	}
return 0;
}
ISR(INT0_vect){				//When an interrupt is invoked, the microcontroller runs the interrupt service routine.
	//PORTB = ~PORTB;
} 
