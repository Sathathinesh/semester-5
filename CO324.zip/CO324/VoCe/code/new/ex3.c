
#include <avr/io.h>
#include <util/delay.h>

#include <string.h>

#define EEPROM_KEY_ADDR 0

#define LCD_PORT PORTD  // Define LCD Port (PORTA, PORTB, PORTC, PORTD)
#define LCD_DPORT DDRD  // Define 4-Bit Pins (PD4-PD7 at PORT D)
#define PIN_RS PD2      // RS Pin
#define PIN_EN PD3      // E Pin

// Keypad
// 0-3 rows
// 4-7 cols


#define MYUBRR 103

// USART Related functions ----------------------------------
void usart_init() {
  // 8bit frame, no parity, 1 stop 8bit

  UCSR0B |= (1 << TXEN0);        //1->enable transmitter
  UCSR0B |= (1 << RXEN0);        //1->enable receiver

  //00-> asynchronous usart, 01-> synchronous usart, 10-> reserved, 11-> master spi
  UCSR0C &= ~(1 << UMSEL01); // 00
  UCSR0C &= ~(1 << UMSEL00);

  //parity check 00-> disabled, 01-> reserved, 10-> enabled, even parity, 11-> enabled, odd parity
  UCSR0C &= ~(1 << UPM01); // 00
  UCSR0C &= ~(1 << UPM00);

  //stop bit select. 0->1 bit, 1->2bit
  UCSR0C &= ~(1 << USBS0); // 0

  //char size.000-> 5-bit, 001-> 6-bit, 010-> 7-bit, 011-> 8-bit, 111-> 9-bit
  UCSR0C &= ~(1 << UCSZ02); // 011
  UCSR0C |= (1 << UCSZ01);
  UCSR0C |= (1 << UCSZ00);

  // baud rate register
  UBRR0H = (unsigned char)(MYUBRR >> 8);
  UBRR0L = (unsigned char)MYUBRR;

}
unsigned char usart_receive() {
  while (((UCSR0A >> RXC0) & 1) == 0) {}
  return (char)UDR0;
}
void usart_send(char data) {
  UDR0 = data;
  while (((UCSR0A >> UDRE0) & 1) == 0) {}
}
// ----------------------------------------------------------


// EEPROM Related functions ---------------------------------
void EEPROMWrite(unsigned int address, char data) {
  while (EECR & (1 << EEPE)); //wait for complete of previous write
  EEAR = address; //set up address and data regs
  EEDR = data;
  EECR |= (1 << EEMPE); //write logical 1 to EEMPE
  EECR |= (1 << EEPE); //start eeprom write
}
char EEPROMRead (unsigned int address) {
  while (EECR & (1 << EEPE)); //wait for complete of previous write
  EEAR = address; //set up address
  EECR |= (1 << EERE); //start eeprom read
  return EEDR;//return data
}
// ----------------------------------------------------------


// Keypad Related functions ---------------------------------
char readKey() {

  int key;
  usart_send('0' + key);

  return '0';
}
// ----------------------------------------------------------


// LCD Related functions ------------------------------------
void lcd_init(void) {
  LCD_DPORT = 0xFF;    // Control LCD Pins (D4-D7)     ?
  _delay_ms(15);      // Wait before LCD activation
  lcd_action(0x02);     // 4-Bit Control
  lcd_action(0x28);    // Control Matrix @ 4-Bit
  lcd_action(0x0c);    // Disable Cursor
  lcd_action(0x06);    // Move Cursor
  lcd_action(0x01);    // Clean LCD
  _delay_ms(2);
}
void lcd_action(unsigned char command) {

  LCD_PORT = (LCD_PORT & 0x0F) | (command & 0xF0);
  LCD_PORT &= ~ (1 << PIN_RS);
  LCD_PORT |= (1 << PIN_EN);
  _delay_us(1);

  LCD_PORT &= ~ (1 << PIN_EN);
  _delay_us(200);

  LCD_PORT = (LCD_PORT & 0x0F) | (command << 4);
  LCD_PORT |= (1 << PIN_EN);
  _delay_us(1);

  LCD_PORT &= ~ (1 << PIN_EN);
  _delay_ms(2);
}
void lcd_clear() {
  lcd_action (0x01);   // Clear LCD
  _delay_ms(2);        // Wait to clean LCD
  lcd_action (0x80);   // Move to Position Line 1, Position 1
}
void lcd_print(char *str) {

  for (int i = 0; str[i] != 0; i++) {
    LCD_PORT = (LCD_PORT & 0x0F) | (str[i] & 0xF0);
    LCD_PORT |= (1 << PIN_RS);
    LCD_PORT |= (1 << PIN_EN);
    _delay_us(1);
    LCD_PORT &= ~ (1 << PIN_EN);
    _delay_us(200);
    LCD_PORT = (LCD_PORT & 0x0F) | (str[i] << 4);
    LCD_PORT |= (1 << PIN_EN);
    _delay_us(1);
    LCD_PORT &= ~ (1 << PIN_EN);
    _delay_ms(2);
  }
}

void lcd_print(char *line1, char *line2) {
  lcd_printOn(0, 0, line1);
  lcd_printOn(1, 0, line2);
}
void lcd_printOn(char row, char pos, char *str) {
  if (row == 0 && pos < 16) {
    lcd_action((pos & 0x0F) | 0x80);
  } else if (row == 1 && pos < 16) {
    lcd_action((pos & 0x0F) | 0xC0);
  }
  lcd_print(str);
}
// ----------------------------------------------------------

void setup() {
  char mode = 0;
  int key = EEPROMRead(EEPROM_KEY_ADDR);

  usart_init();

  lcd_init();
  lcd_print("Encrypt (#) or", "Change Key(*)");

  // Read from  keypad until a valid input
  while (mode != '*' || mode != '#') {
    mode = readKey();
  }

  if (mode == '#') {
    // Encrypt
    modeEncrypt(key);

  } else if (mode == '#') {
    // Change the key
    key = modeChangeKey();
    modeEncrypt(key);
  }

  //lcd_printOn(1, 10, "Now");
  //lcd_clear();

  loop();

}

void modeEncrypt(int key) {
  char msg[16];
  int count = 0, input = 0;

  lcd_clear();
  lcd_print("Enter the text", "(Press # at end)");

  while (input != '#' || count < 16) {

    if (count == 0) lcd_clear();
    input = readKey();

    lcd_print(input);

    msg[count] = input;
    count++;
  }

  // next ?
}

int modeChangeKey() {
  char key = 0;
  lcd_clear();
  lcd_print("Enter a new key:");

  while (!(key >= '0' && key <= '9')) {
    key = readKey();
  }

  // Write the new key into the EEPROM
  EEPROMWrite(EEPROM_KEY_ADDR, (unsigned char)('0' + key));

  return key;
}


void loop() {

}

int main() {
  setup();

  while (1) {
    loop();
  }
}
