import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;

public class MultiServer extends Thread {
    
   MulticastSocket ss ;
  final InetAddress mcIPAddress ;
  final int mcPort=55001;
  boolean stopCapture = false;
  ByteArrayOutputStream byteArrayOutputStream;
  AudioFormat audioFormat;
  TargetDataLine targetDataLine;
  AudioInputStream InputStream;
  SourceDataLine sourceLine;
  byte tempBuffer[] = new byte[10000];
 // byte playBuffer[] = new byte[10000];
  byte[] receiveData = new byte[10000];
  //int ttl = 1;
    public static void main(String[] args) throws UnknownHostException, IOException {
    
       String mcIPStr = "239.1.1.1";
   // MulticastSocket socket;

   // int ttl =1;
    InetAddress mcIPAddress = InetAddress.getByName(mcIPStr);

    // InetAddress mcIPAddress = InetAddress.getByName(239.1.1.1);
    Thread cap = new Thread((Runnable) new MultiServer(mcIPAddress));
    cap.start();
    Thread ply = new Thread((Runnable) new PlayThread(mcIPAddress));
    ply.start();
    }
    
    
    @Override
    public void run() {
        try {
	    this.ss = new MulticastSocket(this.mcPort);
            this.ss.joinGroup(this.mcIPAddress);
           	//this.socket = new MulticastSocket(mcPort);
            this.captureAudio();
          //  socket.setLoopbackMode(true);
            this.CaptureAndSend();

        } catch (SocketException e) {
        } catch (IOException ex) {
         // Logger.getLogger(PClient.class.getName()).log(Level.SEVERE, null, ex);
      } finally {
            this.ss.close();
        }
    }
    public MultiServer(InetAddress mcIPAddress) {
        //this.s=s;
       // this.ss=ss;
     //   this.mcPort=mcPort;
        this.mcIPAddress=mcIPAddress;
     //   throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        
    private AudioFormat getAudioFormat() {
        float sampleRate = 16000.0F;
        int sampleSizeInBits = 16;
        int channels = 2;
        boolean signed = true;
        boolean bigEndian = true;
        return new AudioFormat(sampleRate, sampleSizeInBits, channels, signed, bigEndian);
    }

    public void captureAudio() {

        try {
    
        AudioFormat  adFormat = getAudioFormat();
        DataLine.Info dataLineInfo = new DataLine.Info(TargetDataLine.class, adFormat);
        targetDataLine = (TargetDataLine) AudioSystem.getLine(dataLineInfo);
        targetDataLine.open(adFormat);
        targetDataLine.start();

        } catch (LineUnavailableException e) {
            System.out.println(e);
            System.exit(0);
        }

    }

public void CaptureAndSend(){
   // byte tempBuffer[] = new byte[10000];
    //int ttl =1;
   

        byteArrayOutputStream = new ByteArrayOutputStream();
        stopCapture = false;
        try {
         //   DatagramSocket clientSocket = new DatagramSocket(8786);
         //   InetAddress IPAddress = InetAddress.getByName("127.0.0.1");
            while (!stopCapture) {
                int cnt = targetDataLine.read(tempBuffer, 0, tempBuffer.length);
                if (cnt > 0) {
                    DatagramPacket sendPacket = new DatagramPacket(tempBuffer, tempBuffer.length, mcIPAddress, 55000);
                    ss.send(sendPacket);
                 //   ss.setLoopbackMode(true);
                   // runVOIP();
                   // byteArrayOutputStream.write(tempBuffer, 0, cnt);
                }
            }
            byteArrayOutputStream.close();
        } catch (IOException e) {
            System.out.println("CaptureThread::run()" + e);
            System.exit(0);
        }
    }
}

