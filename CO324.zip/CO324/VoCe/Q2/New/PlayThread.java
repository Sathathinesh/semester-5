
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Thinesh
 */
class PlayThread extends Thread {


  MulticastSocket s;
  InetAddress mcIPAddress ;
  int mcPort=55000;
  boolean stopCapture = false;
  ByteArrayOutputStream byteArrayOutputStream;
  AudioFormat audioFormat;
  TargetDataLine targetDataLine;
  AudioInputStream InputStream;
  SourceDataLine sourceLine;
  byte tempBuffer[] = new byte[10000];
 // byte playBuffer[] = new byte[10000];
  byte[] receiveData = new byte[10000];

    PlayThread(InetAddress mcIPAddress) {
     //   throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
     this.mcIPAddress=mcIPAddress;
    }

     private AudioFormat getAudioFormat() {
        float sampleRate = 16000.0F;
        int sampleSizeInBits = 16;
        int channels = 2;
        boolean signed = true;
        boolean bigEndian = true;
        return new AudioFormat(sampleRate, sampleSizeInBits, channels, signed, bigEndian);
    }  
    
  
    @Override
    public void run() {
        try {
	    byteArrayOutputStream = new ByteArrayOutputStream();
            int cnt;
            this.s = new MulticastSocket(this.mcPort);
            this.s.joinGroup(this.mcIPAddress);

            runVOIP();
            while ((cnt = InputStream.read(receiveData, 0, receiveData.length)) != -1) {
                if (cnt > 0) {
		    byteArrayOutputStream.write(receiveData, 0, cnt);
                    this.sourceLine.write(receiveData, 0, cnt);
                }
            }
            //  sourceLine.drain();
            // sourceLine.close();
        } catch (IOException e) {
            System.out.println(e);
            System.exit(0);
        }
    }
    public void runVOIP() throws IOException {
        //  DatagramSocket serverSocket = new DatagramSocket(9786);
        //  
        while (true) {
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            s.receive(receivePacket);
            //  s.setLoopbackMode(true);
            // System.out.println("RECEIVED: " + receivePacket.getAddress().getHostAddress() + " " + receivePacket.getPort());
            try {
                byte audioData[] = receivePacket.getData();
                InputStream byteInputStream = new ByteArrayInputStream(audioData);
                AudioFormat adFormat = getAudioFormat();
                InputStream = new AudioInputStream(byteInputStream, adFormat, audioData.length / adFormat.getFrameSize());
                DataLine.Info dataLineInfo = new DataLine.Info(SourceDataLine.class, adFormat);
                sourceLine = (SourceDataLine) AudioSystem.getLine(dataLineInfo);
                sourceLine.open(adFormat);
                sourceLine.start();
                FloatControl control = (FloatControl)sourceLine.getControl(FloatControl.Type.MASTER_GAIN);
                control.setValue(control.getMaximum());
               
            } catch (LineUnavailableException e) {
                System.out.println(e);
                System.exit(0);
            }
        }
}

}
