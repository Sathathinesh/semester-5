import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.io.*;
import java.text.*;
import java.util.*;
import java.net.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.Line;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;
import javax.swing.JOptionPane;
 
/*  ww  w .j av  a 2 s .c  o  m*/
public class MainClientNew extends Thread {
   final MulticastSocket s ;
  public static void main(String[] args) throws Exception {
    int mcPort = 12345;
    String mcIPStr = "230.1.1.1";
    MulticastSocket s;
    InetAddress mcIPAddress = null;
    mcIPAddress = InetAddress.getByName(mcIPStr);
    s = new MulticastSocket(mcPort);
  /*  System.out.println("Multicast Receiver running at:"
        + mcSocket.getLocalSocketAddress());*/
    s.joinGroup(mcIPAddress);
    MainClientNew m  = new MainClientNew(s);
    m.start();

    s.leaveGroup(mcIPAddress);
  }
  public MainClientNew(MulticastSocket s){
    this.s = s;
}
public void run(){
    try
    {
        // obtaining input and out streams
        DataInputStream dis = new DataInputStream(s.getInputStream());
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        System.out.println("Connection Created");
        PeerClient peer = new PeerClient(s,dis,dos);
        peer.captureAudio();
        // the following loop performs the exchange of
        // information between client and client handler

        // closing resources
      //  s.close();
        dis.close();
        dos.close();
        s.close();
    }catch(Exception e){
        e.printStackTrace();
    }
}
    // DatagramPacket packet = new DatagramPacket(new byte[1024], 1024);

    // System.out.println("Waiting for a  multicast message...");
    // mcSocket.receive(packet);
    // String msg = new String(packet.getData(), packet.getOffset(),
    //     packet.getLength());
    // System.out.println("[Multicast  Receiver] Received:" + msg);
}