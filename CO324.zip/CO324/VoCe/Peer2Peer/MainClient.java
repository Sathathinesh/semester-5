import java.io.*;
import java.net.*;
import java.io.IOException;
 
 public class MainClient extends Thread{
   //  InetAddress ip
	//final Socket s;
	 
 public static void main(String[] args) throws IOException
    {
		  //  String IP = JOptionPane.showInputDialog("Input Your IP Server : ");
            // getting localhost ip
            String IP = args[0] ;
           // System.out.println(args[0]);
            InetAddress ip = InetAddress.getByName(IP);
           // establish the connection with server port 5056
            Socket s = new Socket(ip, 5056);
           // MainClient m  = new MainClient(s);
			//m.start();
    //}
	//public MainClient(Socket s){
	//	this.s = s;
	//}
	
	//public void run(){
		try
        {
            DataOutputStream dos;
                try ( // obtaining input and out streams
                        DataInputStream dis = new DataInputStream(s.getInputStream())) {
                    dos = new DataOutputStream(s.getOutputStream());
                    System.out.println("Connection Created");
                    PeerClient peer = new PeerClient(s,dis,dos);
                    peer.captureAudio();
                    // the following loop performs the exchange of
                    // information between client and client handler
                    // closing resources
                    s.close();
                }
            dos.close();
        }catch(IOException e){
        }
	}
}