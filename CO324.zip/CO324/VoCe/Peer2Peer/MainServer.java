import java.io.*;
import java.net.*;
import java.io.IOException;

 
 public class MainServer extends Thread{
 
 public static void main(String[] args) throws IOException
    {
            ServerSocket ss = new ServerSocket(5056);
            Socket s = null;

            try
            {
                s = ss.accept();

                System.out.println(" client is connected :" + s);

                DataOutputStream dos;
                try ( // obtaining input and out streams
                        DataInputStream dis = new DataInputStream(s.getInputStream())) {
                    dos = new DataOutputStream(s.getOutputStream());
                    PeerServer peer = new PeerServer(s,dis,dos);
                    peer.captureAudio();
                    s.close();
                }
                dos.close();

            }
            catch (IOException e){
                s.close();
            }
    }
	
}