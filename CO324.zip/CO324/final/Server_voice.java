
//package server_voice;

public class Server_voice {

    public static boolean calling  = false ;
    
    public static void main(String[] args) {
       Server fr =new Server();
       fr.setVisible(true);
       
    }
    
}
