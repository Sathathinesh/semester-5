 import java.io.*;
import java.text.*;
import java.util.*;
import java.net.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.Line;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;

 
 public class Main{
 
 public static void main(String[] args) throws IOException
    {
            ServerSocket ss = new ServerSocket(5056);
            Socket s = null;

            try
            {
                s = ss.accept();

                System.out.println(" client is connected :");

                // obtaining input and out streams
                DataInputStream dis = new DataInputStream(s.getInputStream());
                DataOutputStream dos = new DataOutputStream(s.getOutputStream());

                Peer peer = new Peer(s,dis,dos);
                peer.captureAudio();

                s.close();
                dis.close();
                dos.close();

            }
            catch (Exception e){
                s.close();
                e.printStackTrace();
            }
    }
}