import java.io.*;
import java.text.*;
import java.util.*;
import java.net.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.Line;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;
import javax.swing.JOptionPane;
 
 public class MainClient extends Thread{
   //  InetAddress ip
	final Socket s;
	 
 public static void main(String[] args) throws IOException
    {
		    String IP = JOptionPane.showInputDialog("Input Your IP Server : ");
            // getting localhost ip
            InetAddress ip = InetAddress.getByName(IP);
           // establish the connection with server port 5056
            Socket s = new Socket(ip, 5056);
            MainClient m  = new MainClient(s);
			m.start();
    }
	public MainClient(Socket s){
		this.s = s;
	}
	
	public void run(){
		try
        {
            // obtaining input and out streams
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            System.out.println("Connection Created");
            PeerClient peer = new PeerClient(s,dis,dos);
            peer.captureAudio();
            // the following loop performs the exchange of
            // information between client and client handler

            // closing resources
            s.close();
            dis.close();
            dos.close();
        }catch(Exception e){
            e.printStackTrace();
        }
	}
}