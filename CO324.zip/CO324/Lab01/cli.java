package javaapplication4;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.net.* ;


/**
 *
 * @author Thinesh
 */
public class JavaApplication4 {
 

   //Give a standard packet size. 
   private final static int packetsize = 100 ;
   
   public static void main( String args[] )
   {
       // Check the whether the arguments are given
      if( args.length != 2 )
      {
         System.out.println( "usage: java DatagramClient host port" ) ;
         return ;
      }

      //Q1: Create a datagram socket object here
	 
	  
      try
      {
          // Convert the arguments to ensure that they are valid
         InetAddress host = InetAddress.getByName( args[0] ) ;
         int port         = Integer.parseInt( args[1] ) ;

         //Q1: Construct the socket
    

         byte [] data = "The message watnts to pass".getBytes() ;
		 
         //Q2: Construct the datagram packet
		 
         // Send the packet
         socket.send( packet ) ;
        

         // Prepare the packet for receive
         packet.setData( new byte[packetsize] ) ;

         // Wait for a response from the server
         socket.receive( packet ) ;

         // Print the response
         System.out.println(packet.getData()) ;
		 
		 socket.close() ;
      }
      catch( NumberFormatException | UnknownHostException e )
      {
         System.out.println( e ) ;
      }
     
   }

    private static class packet {

        private static void setData(byte[] b) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private static String getData() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        public packet() {
        }
    }
}
class socket {

    static void close() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
