
class Q4{
    static int [][] cost = {{0, 3, 12, 23, 41}, // cost from 0 
			    {0, 0,  2,  4, 34}, // cost from 1 
			    {0, 0,  0,  12, 3}, // cost from 2 
			    {0, 0,  0,  0, 12}, // cost from 3 
			    {0, 0,  0,  0,  0}  // cost from 4 
    };

    static int iMax = 5;
    static int jMax = 5;

    // Just for testing, min cost from 0 to 4 should be 8.
    static int answer = 8; 
    static int N=5;

     public static int minCost(int i,int j) {
              
        int min[] = new int[N];
        for (int k=0; k<N; k++) 
           min[k] = Integer.MAX_VALUE; 
           min[0] = 0; 
       
        for (i=0; i<N; i++) 
           for (j=i+1; j<N; j++) 
              if (min[j] > min[i] + cost[i][j]) {
                           min[j] = min[i] + cost[i][j]; 
              }
            return min[N-1]; 
			}

    public static void main(String [] args) {
	int r = minCost(0,4); 
	
	if(r == answer)
	    System.out.println("Your implementation might be correct");
	else
	    System.out.println("Too bad. Try again (" + r + ")");
    }
}
    
