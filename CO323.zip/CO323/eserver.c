#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<arpa/inet.h>

#define MAX_SIZE 1024

int main()
{
   int sockfd,newsockfd;
   socklen_t len;
   char buffer[1024];
   
   struct sockaddr_in serveraddr,clientaddr;
   sockfd=socket(PF_INET,SOCK_STREAM,0);
   serveraddr.sin_family=PF_INET;
   serveraddr.sin_port=htons(12345);
   serveraddr.sin_addr.s_addr=inet_addr("127.0.0.1");

   bind(sockfd,(struct sockaddr*)&serveraddr,sizeof(serveraddr));
   listen(sockfd,1024);

   printf("\n\n Bind Done");
   printf("\n\n Waiting for Client's Message.............");
   printf("\n ");
   len = sizeof(clientaddr);
          
          newsockfd = accept(sockfd,(struct sockaddr*)&clientaddr,&len);
     
          recv(newsockfd,buffer,MAX_SIZE,0);
         
      printf("\n Client's Message : %s\n",buffer);
             send(newsockfd,buffer,MAX_SIZE,0);
             memset(buffer,'\0', MAX_SIZE);
        
   return 0;
}
