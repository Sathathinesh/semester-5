#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<stdio_ext.h>
#include<arpa/inet.h>
#include<ctype.h>
#define MAX_SIZE 2048
#define QUEUE_LIMIT 12

int main()
    {
       int clientsocket,count=0;
       char buffer[MAX_SIZE];

        struct sockaddr_in serverAddress;
        clientsocket=socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);

        serverAddress.sin_family=AF_INET;
        serverAddress.sin_port=htons(12345);
        serverAddress.sin_addr.s_addr=inet_addr("127.0.0.1");
        memset(buffer,'\0', MAX_SIZE);

        memset(buffer,'\0', MAX_SIZE);

        connect(clientsocket,(struct sockaddr *) &serverAddress,sizeof(serverAddress));

           printf("\nEnter string:");

           scanf("%s",buffer);
           char *sms=buffer;
           send(clientsocket,sms,MAX_SIZE,0);
           memset(buffer,'\0', MAX_SIZE);
           recv(clientsocket,buffer,MAX_SIZE,0);
           printf("\n Message from server: %s\n",buffer);
           memset(buffer,'\0', MAX_SIZE);
     
   return 0;
    }