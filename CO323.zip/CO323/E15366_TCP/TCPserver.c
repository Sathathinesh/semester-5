#include<string.h>
#include<sys/ioctl.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<stdio.h>
#include<net/if_arp.h>

int main()
{
int sd,b,cd;
struct fname[50],op[1000];
struct sockaddr_in caddr,saddr;
FILE *fp;
socklen_t clen=sizeof(caddr);
sd=socket(AF_INET,SOCK_STREAM,0);
if(sd!=-1)
printf(“socket is created”);
else
printf(“socket is not created”);
saddr.sin_family=AF_INET;
saddr.sin_port=htons(2500);
saddr.sin_addr.s_addr=htonl(INADDR_ANY);
b=bind(sd,(struct sockaddr*)&saddr,sizeof(saddr));
if(b==0)
printf(“binded successfully”);
else
printf(“binding failed’);
listen(sd,5);
cd=accept(sd,(struct sockaddr*)&caddr,&clen);
recv(cd,fname,sizeof(fnmae),0);
fp=open(fname,”w”);
fwrite(op,strlen(op),1,fp);
printf(“the file has been transferred”);
close(fd);
close(cd);
fclose(fp);
return 0;
}