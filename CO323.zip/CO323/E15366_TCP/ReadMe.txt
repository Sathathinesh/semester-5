This is the INPUT and OUTPUT of TCPclient.c 
{ Enter the server ip address 127.0.0.1
Socket created
Connected to the server
Enter the file name Serverfile.txt
Serverfile.txt }

This is the TCPserver.c INPUT and OUTPUT 
{Socket is created
Binded successfully
Enter the file name serverfile.txt
The file has been transferred
Serverfile.txt}