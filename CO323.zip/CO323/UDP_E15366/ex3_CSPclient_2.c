/* Excercises 3*/
/* 3.2*/
/* Sample UDP client for CSP server */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main(int argc, char**argv)
{
int sockfd,n1,n2;
struct sockaddr_in servaddr;
char s1[1000];
char recvline[1000];
//Checking the no of input arguments.
int n 
if (argc != 3)
{
printf("usage: ./%s <IP address> <noOfSentences>\n",argv[0]);//printing the required pattern.
return -1;
}
else {
	n= atoi(argv[2]);
}
if(n>0){ 
sockfd=socket(AF_INET,SOCK_DGRAM,0);
bzero(&servaddr,sizeof(servaddr));
servaddr.sin_family = AF_INET;
servaddr.sin_addr.s_addr=inet_addr(argv[1]);
servaddr.sin_port=htons(32000);
sendto(sockfd,argv[2],1000,0,(struct sockaddr *)&servaddr,sizeof(servaddr));
n1=recvfrom(sockfd,recvline,10000,0,NULL,NULL);
recvline[n1]=0;
printf("%s\n",recvline);
int i=0;
//while loop that iterates n times.
while(i<n)
{
scanf("%s",s1);
sendto(sockfd,s1,strlen(s1),0,(struct sockaddr*)&servaddr,sizeof(servaddr));
n2=recvfrom(sockfd,recvline,10000,0,NULL,NULL);
recvline[n2]=0;
printf("Capitalized:%s\n",recvline);
i++;
}
}
else{
printf("Invalid integer\n");
}
return 0;
}

