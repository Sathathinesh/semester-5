/* Excercises 1*/
/* 3. */
/* Sample UDP CSP server that uses the hypothetical Capitalizer Service Protocol to provide a capitalizer service */
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h> 
int main(int argc, char**argv)
{
int sockfd,n1,n2;
struct sockaddr_in servaddr, cliaddr;
socklen_t len;
char mesg[1000];
char s1[1000];
char* banner= "ack";
sockfd=socket(AF_INET,SOCK_DGRAM,0);
servaddr.sin_family = AF_INET;
servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
servaddr.sin_port=htons(32000);
bind(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr));
len = sizeof(cliaddr);
n1 = recvfrom(sockfd,mesg,1000,0,(struct sockaddr *)&cliaddr,&len);
sendto(sockfd,banner,n1,0,(struct sockaddr *)&cliaddr,sizeof(cliaddr));
mesg[n1] = 0;.
//printf("Received: %s\n",mesg);
int i=0;
int n = atoi(mesg);
//while loop that iterates n times. 
while(i<n){
n2 = recvfrom(sockfd,s1,1000,0,(struct sockaddr *)&cliaddr,&len);

for(int j=0; s1[j]!='\0'; j++)
    {
        if(s1[j]>='a' && s1[j]<='z')
        {
            s1[j] = s1[j] - 32;
        }
    }
sendto(sockfd,s1,n2,0,(struct sockaddr *)&cliaddr,sizeof(cliaddr));
s1[n2]=0;//null terminate.
printf("Received a sentence!\n");
i++;
}
return 0;
}
