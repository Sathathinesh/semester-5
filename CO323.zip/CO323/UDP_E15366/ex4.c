/*Write a time server that, when connected, sits in a loop and sends the current time each second to
the receiver.*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <stdio.h>
#include <time.h>

int main(int argc, char**argv){
	int sockfd,n;
	struct sockaddr_in servaddr, cliaddr;
	socklen_t len;
	char mesg[1000];
	//char* banner = "Hello UDP server! This is UDP client send me the current time";
	
	sockfd=socket(AF_INET,SOCK_DGRAM,0);	
	
	servaddr.sin_family = AF_INET;		
	servaddr.sin_addr.s_addr=htonl(INADDR_ANY);	
	servaddr.sin_port=htons(32000);
	
	bind(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr));
	len = sizeof(cliaddr);
	
	while(1){
		time_t ltime;
		time(&ltime); 

		n=recvfrom(sockfd,ctime(&ltime),1000,0,(struct sockaddr*)&cliaddr,&len);
	
		sendto(sockfd,ctime(&ltime),n,0,(struct sockaddr*)&cliaddr,sizeof(cliaddr));

	}
	return 0;
}